// from data.js
import data from './data'
var tableData = data;

// YOUR CODE HERE!