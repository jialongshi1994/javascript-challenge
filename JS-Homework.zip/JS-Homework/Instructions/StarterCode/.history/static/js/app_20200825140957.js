// from data.js
const tableData = data

// YOUR CODE HERE!