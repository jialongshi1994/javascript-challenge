// from data.js
const tableData = data

// YOUR CODE HERE!

// 初始化页面
function initPage() {
    // 
}
// 绑定查询事件