// from data.js
const tableData = data

// YOUR CODE HERE!

const $datetime = document.getElementById('datetime')
const $city = document.getElementById('city')
const $state = document.getElementById('state')
const $country = document.getElementById('country')
const $shape = document.getElementById('shape')
const $ufoTableBody = document.getElementById('ufo-table-body')
const $filterBtn = document.getElementById('filter-btn')
initPage()
$filterBtn.onclick = function() {
    const arr = query()
    debugger
    let res = ''
    arr.forEach(item => {
        res += `
        <tr>
            <td>${item.datetime}</td>
            <td>${item.city}</td>
            <td>${item.state}</td>
            <td>${item.country}</td>
            <td>${item.shape}</td>
            <td>${item.durationMinutes}</td>
            <td>${item.comments}</td>
        </tr>`
    })
    $ufoTableBody.innerHTML = res
}

// 初始化页面函数
function initPage() {
    // 获取选项
    $city.innerHTML = getOptions('city')
    $state.innerHTML = getOptions('state')
    $country.innerHTML = getOptions('country')
    $shape.innerHTML = getOptions('shape')
}

// 绑定查询事件
function query() {
    const res = []
    tableData.forEach(item => {
        if ((item.datetime.includes($datetime.value)) &&
            (item.city.includes($city.value)) &&
            (item.state.includes($state.value)) &&
            (item.country.includes($country.value)) &&
            (item.shape.includes($shape.value))) {
            res.push(item)
        }
    })
    return res
}

// 获取下拉选项字符串
function getOptions(name) {
    // 获取目标数组
    const arr = tableData.map(item => item[name])

    // 去重数组
    const res = []
    arr.forEach(item => {
        if (!res.includes(item)) {
            res.push(item)
        }
    })

    // 排序数组
    res.sort()

    // 处理数组为字符串
    let str = '<option value="">all</option>'
    res.forEach(item => {
        str += `<option value="${item}">${item}</option>`
    })
    return str
}