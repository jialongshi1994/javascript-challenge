// from data.js
const tableData = data

// YOUR CODE HERE!

// 初始化页面
function initPage() {
    // 获取选项
}
// 绑定查询事件

// 获取下拉选项字符串

// 获取表格字符串