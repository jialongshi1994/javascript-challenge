// from data.js
const tableData = data

// YOUR CODE HERE!

const city
    // 初始化页面
function initPage() {
    // 获取选项
    getOptions('city')
    getOptions('state')
    getOptions('country')
    getOptions('shape')
}
// 绑定查询事件

// 获取下拉选项字符串

// 获取表格字符串
function getOptions(str) {
    const arr = tableData.map(item => item[str])
    const res = []
    arr.forEach(item => {
        if (!res.includes(item)) {
            res.push(item)
        }
    })
    return res
}

function getOptionsStr(arr) {
    return arr.map(item => `<option value="${item}">${item}</option>`).join('')
}

function simpleData(str) {
    return
}