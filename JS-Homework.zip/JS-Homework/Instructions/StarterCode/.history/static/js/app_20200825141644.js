// from data.js
const tableData = data

// YOUR CODE HERE!

// 初始化页面

// 点击查询