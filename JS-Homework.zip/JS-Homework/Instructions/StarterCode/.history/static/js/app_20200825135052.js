// from data.js
// import { data } from './data'
let { data } = require('./data');
var tableData = data;
console.log(tableData)

// YOUR CODE HERE!