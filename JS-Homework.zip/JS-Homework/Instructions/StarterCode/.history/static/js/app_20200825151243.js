// from data.js
const tableData = data

// YOUR CODE HERE!

const $datetime = document.getElementById('datetime')
const $city = document.getElementById('city')
const $state = document.getElementById('state')
const $country = document.getElementById('country')
const $shape = document.getElementById('shape')
const $ufoTable = document.getElementById('ufo-table')
const $filterBtn = document.getElementById('filter-btn')
initPage()
$filterBtn.onclick = function() {
    query()
}

// 初始化页面函数
function initPage() {
    // 获取选项
    $city.innerHTML = getOptions('city')
    $state.innerHTML = getOptions('state')
    $country.innerHTML = getOptions('country')
    $shape.innerHTML = getOptions('shape')
}
// 绑定查询事件
function query() {
    return tableData.find(item => {
        return $datetime.value.includes(item.datetime) &&
            $city.value.includes(item.city) &&
            $state.value.includes(item.state) &&
            $country.value.includes(item.country) &&
            $shape.value.includes(item.shape)
    })
}

// 获取下拉选项字符串

// 获取表格字符串
function getOptions(str) {
    const arr = tableData.map(item => item[str])
    let res = '<option value="">all</option>'
    arr.forEach(item => {
        if (!res.includes(item)) {
            res += `<option value="${item}">${item}</option>`
        }
    })
    return res
}