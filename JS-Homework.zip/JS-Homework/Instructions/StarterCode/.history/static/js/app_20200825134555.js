// from data.js
import data from './data'
var tableData = data;
console.log(tableData)

// YOUR CODE HERE!