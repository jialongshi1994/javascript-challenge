// from data.js
var tableData = data;
console.log(tableData)

// YOUR CODE HERE!